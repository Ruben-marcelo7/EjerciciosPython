resultado = input ("Ingresa tu edad: ")
print(type(resultado))
numero = int(resultado)
print(numero +2)