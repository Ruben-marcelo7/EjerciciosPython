lenguajes = ["Python", "Ruby", "PHP", "Javascript", "Java"]

for lenguaje in lenguajes:
    print(lenguaje)


    i = 0
while i < len(lenguajes):
    print (lenguajes[i])
    i = i + 1 