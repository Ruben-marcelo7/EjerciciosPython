lenguajes = ["Python", "Ruby", "PHP", "Javascript", "Java"]

i = 1 
while i <= 5 :
    print(i)
    i = i + 1

i = 1 
while i <= 5 :
    print(i * "el weta ")
    i = i + 1

i = 0
while i < len(lenguajes):
    print (lenguajes[i])
    i = i + 1 