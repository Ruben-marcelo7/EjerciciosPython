n1 = 10 
n2 = 15 
print(n1 > n2)
print(n1 < n2)
print(n1 <= 10)
print(n1 >= 10)
print(n2 == 15)