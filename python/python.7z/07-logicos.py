edad = 22

print (edad > 18 and edad < 30)
print (edad > 18 or edad < 30)
print (not (edad > 17))
