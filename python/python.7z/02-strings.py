texto = "Hola Mundo"
print (texto.upper())
print (texto.lower())
print (texto.find("Mun"))
print (texto.find("mun"))
nuevoTexto = texto.replace("Mun", "chanchito feliz")
print (texto, nuevoTexto)
print("mundo" in texto)
