puntaje = 93

if puntaje >= 95:
    print ("Aprovado con honores")
elif puntaje >= 50:
    print("Alumno aprovado")
else:
    print("Alumno reprovado")

print("Fuera del if")