resultado = input ("Ingresa tu edad: ")
print(type(resultado))
print(resultado + 22)