lenguajes = ["Python", "Ruby", "PHP", "Javascript", "Java"]
lenguajes[1] = "Go"
print (lenguajes[-3])
print (lenguajes[1:3])
print (lenguajes[:3])
print (lenguajes[1:])