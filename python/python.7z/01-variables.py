variable = "Hola mundo"
numero = 42 
decimal = 10.5
verdadero = True
falso = False